#!/bin/bash

evtest
